<?php
session_start();

$email = "";
$password = "";
$confirmpassword = "";
$firstname = "";
$middle = "";
$lastname = "";
$age = "";
$idnumber = "";
$yearlevel = "";
$gender = "";
$contact = "";
$address = "";
$errors = array(); 

$db = mysqli_connect('localhost', 'root', '', 'davedb');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reg_user'])) {

  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);
  $confirmpassword = mysqli_real_escape_string($db, $_POST['confirmpassword']);
  $firstname = mysqli_real_escape_string($db, $_POST['firstname']);
  $middle = mysqli_real_escape_string($db, $_POST['middle']);
  $lastname = mysqli_real_escape_string($db, $_POST['lastname']);
  $age = mysqli_real_escape_string($db, $_POST['age']);
  $idnumber = mysqli_real_escape_string($db, $_POST['idnumber']);
  $yearlevel = mysqli_real_escape_string($db, $_POST['yearlevel']);
  $gender = mysqli_real_escape_string($db, $_POST['gender']);
  $course = mysqli_real_escape_string($db, $_POST['course']);
  $contact = mysqli_real_escape_string($db, $_POST['contact']);
  $address = mysqli_real_escape_string($db, $_POST['address']);

  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }
  if ($password != $confirmpassword) {
	array_push($errors, "Password does not match");
  }

  $user_check_query = "SELECT * FROM account WHERE email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { 
    if ($user['email'] === $email)
      {
        array_push($errors, "Email already exists");
      } 
  }

  if (count($errors) == 0) {
  	$Pass_password = ($password);

    $query = "INSERT INTO account (email, password, firstname, lastname, age, contact, idnumber, address, gender, yearlevel, middle, course) 
              VALUES ('$email', '$password', '$firstname', '$lastname', '$age', '$contact', '$idnumber', '$address', '$gender', '$yearlevel', '$middle', '$course')";
    $result = mysqli_query($db, $query);
    if ($result) {
        $_SESSION['email'] = $email;
        $_SESSION['success'] = "You are now registered and logged in";
        header('location: index.php');
        exit();
    } else {
        array_push($errors, "Registration failed. Please try again later.");
    }
}
}

// LOGIN-QUERRY
if (isset($_POST['login_user'])) {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($email)) {
    array_push($errors, "Email is required");
  }
  if (empty($password)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    if ($email === 'admin' && $password === 'admin') {
      $_SESSION['email'] = $email;
      $_SESSION['success'] = "You are now logged in as admin";
      header('location: adminsearch.php');
    } else {
      $password = ($password);
      $query = "SELECT * FROM account WHERE email ='$email' AND password='$password'";
      $results = mysqli_query($db, $query);
      if (mysqli_num_rows($results) == 1) {
        $_SESSION['email'] = $email;
        $_SESSION['success'] = "You are now logged in";
        header('location: student.php');
      } else {
        array_push($errors, "Wrong username/password combination");
      }
    }
  }
}

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
}

// SIT_IN QUERRY

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sit_in'])) {
    $id_number = mysqli_real_escape_string($db, $_POST['id_number']);
    $firstname = mysqli_real_escape_string($db, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($db, $_POST['lastname']);
    $yearlevel = mysqli_real_escape_string($db, $_POST['yearlevel']);
    $course = mysqli_real_escape_string($db, $_POST['course']);
    $purpose = mysqli_real_escape_string($db, $_POST['purpose']);
    $lab_room = mysqli_real_escape_string($db, $_POST['lab_room']);
  
    $sql = "INSERT INTO sitinsession (firstname, lastname, year, course, id_number, purpose, lab_room, sit_in_time)
            VALUES ('$firstname', '$lastname', '$yearlevel', '$course', '$id_number','$purpose', '$lab_room', NOW())";

    if (mysqli_query($db, $sql)) {
        echo "Sit-in record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($db);
    }
}

// END-SESSION QUERRY

function endSession($id, $db) {
    $sql_fetch_session = "SELECT * FROM sitinsession WHERE id = '$id'";
    $result_fetch_session = mysqli_query($db, $sql_fetch_session);

    if ($result_fetch_session && mysqli_num_rows($result_fetch_session) > 0) {
        $session_data = mysqli_fetch_assoc($result_fetch_session);

        $sql_insert_ended_session = "INSERT INTO endedsessions (id, firstname, lastname, id_number, course, year, lab_room, purpose, sit_in_time, sit_out_time) 
            VALUES (NULL, '{$session_data['firstname']}', '{$session_data['lastname']}', '{$session_data['id_number']}', '{$session_data['course']}', '{$session_data['year']}', '{$session_data['lab_room']}', '{$session_data['purpose']}', '{$session_data['sit_in_time']}', NOW())";
        mysqli_query($db, $sql_insert_ended_session);

        $sql_delete_session = "DELETE FROM sitinsession WHERE id = '$id'";
        mysqli_query($db, $sql_delete_session);

        $sql_update_remaining = "UPDATE account SET remaining = CASE WHEN remaining > 0 THEN remaining - 1 ELSE 0 END WHERE idnumber = '{$session_data['id_number']}'";
        mysqli_query($db, $sql_update_remaining);

        return array('status' => 'success', 'message' => 'Session ended successfully.');
    } else {
        return array('status' => 'error', 'message' => 'Session not found.');
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['end_session'])) {
    $session_id = mysqli_real_escape_string($db, $_POST['session_id']);
    $response = endSession($session_id, $db);
    echo json_encode($response);
    exit();
}

// =================================== RESET PASSWORD ADMIN / SESSION ========================================

if (isset($_POST['reset_session'])) {
  $idnumber = $_POST['idnumber'];
  $sql = "UPDATE account SET remaining = 30 WHERE idnumber = '$idnumber'";
  if (mysqli_query($db, $sql)) {
  } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($db);
  }
}

// edit student
if (isset($_POST['admin_edit_student'])) {
  $id_number = mysqli_real_escape_string($db, $_POST['id_number']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  $query = "UPDATE account SET password = '$password' WHERE idnumber = '$id_number'";

  if (mysqli_query($db, $query)) {

  } else {

  }
}
// ANNOUNCEMENT//
if (isset($_POST['post_announcement'])) {
  $announcement = mysqli_real_escape_string($db, $_POST['announcement']);
  $query = "INSERT INTO announcement (ann_notes, ann_date) VALUES ('$announcement', now())";

  mysqli_query($db, $query);

  header("Location: postannounce.php");
  exit();

}

// FEEDBACK//
if (isset($_POST['my_feedback'])) {
  $feedback = mysqli_real_escape_string($db, $_POST['feedback']);

  $email = $_SESSION['email'];
  $user_query = "SELECT user_id FROM account WHERE email = '$email'";
  $user_result = mysqli_query($db, $user_query);
  $user_row = mysqli_fetch_assoc($user_result);
  $user_id = $user_row['user_id'];

  $query = "INSERT INTO feedback (feedback_notes, feedback_date, user_id) VALUES (?, NOW(), ?)";
  $stmt = mysqli_prepare($db, $query);
  mysqli_stmt_bind_param($stmt, "si", $feedback, $user_id);

  if (mysqli_stmt_execute($stmt)) {
      header("Location: feedback.php");
      exit();
  } else {

      echo "Error: " . mysqli_error($db);
  }

  mysqli_stmt_close($stmt);
}
// STUDENT DELETE QUERY /
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['idnumber'])) {
  $studentId = $_POST['idnumber'];


  $delete_query = "DELETE FROM account WHERE idnumber = '$studentId'";
  $delete_result = mysqli_query($db, $delete_query);

  if ($delete_result) {

      $select_query = "SELECT * FROM account WHERE idnumber = '$studentId'";
      $select_result = mysqli_query($db, $select_query);

      if ($select_result && mysqli_num_rows($select_result) > 0) {
          $student_info = mysqli_fetch_assoc($select_result);
      }
    }
}
// SEARCH QUERRY FROM ADMINDELETE //
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['search_idnumber'])) {
  $search_id = $_POST['search_idnumber'];

  if (!empty($search_id)) { 
      $query = "SELECT * FROM account WHERE idnumber = '$search_id'";
      $result = mysqli_query($db, $query);

      if ($result && mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
              echo '<tr>
                      <td>'.strtoupper($row['firstname']).'</td>
                      <td>'.strtoupper($row['lastname']).'</td>
                      <td>'.$row['idnumber'].'</td>
                      <td>'.$row['course'].'</td>
                      <td>'.$row['yearlevel'].'</td>
                      <td>
                          <form method="post" action="admindelete.php">
                              <input type="hidden" name="idnumber" value="'.$row['idnumber'].'">
                              <button type="submit" name="delete_student" class="btn btn-danger">Delete</button>
                          </form>
                      </td>
                    </tr>';
          }
      } else {
          echo '<tr><td colspan="6">No results found.</td></tr>';
      }
  } else {

  }
} else {

}
// update computers-available
//if ($_SERVER["REQUEST_METHOD"] == "POST") {

 // $roomId = $_POST['roomId'];
 // $newValue = $_POST['newValue'];

  // Update computers available in the database
  //$update_sql = "UPDATE available_rooms SET computers_available = '$newValue' WHERE id = '$roomId'";
  //if (mysqli_query($db, $update_sql)) {
  //    echo 'success';
  //} else {
 //     echo 'error';
  //}
//} else {
 // echo 'Invalid request method.';
//}

?>