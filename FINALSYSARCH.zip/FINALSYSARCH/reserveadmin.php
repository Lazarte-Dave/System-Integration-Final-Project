<?php
include('db.php');

// login validation
if (!isset($_SESSION['email'])) {
    header('Location: index.php');
    exit();
}

$email = $_SESSION['email'];

// get user infos
$sql = "SELECT * FROM account WHERE email = '$email'";
$result = mysqli_query($db, $sql);
$student = mysqli_fetch_assoc($result);

$idNumber = $student['idnumber'];

// get avaible rooms
$sql = "SELECT * FROM available_rooms";
$rooms_result = mysqli_query($db, $sql);

// adding room submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_room'])) {

    $room_name = mysqli_real_escape_string($db, $_POST['room_name']);
    $capacity = $_POST['capacity'];
    $computers_available = $_POST['computers_available'];

    // insertion to databsae
    $insert_sql = "INSERT INTO available_rooms (room_name, capacity, computers_available) VALUES ('$room_name', '$capacity', '$computers_available')";
    mysqli_query($db, $insert_sql);

    header('Location: reserveadmin.php');
    exit(); 
}

// reservation request button
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_reservation'])) {

    $room_id = $_POST['room_id'];
    $reason = mysqli_real_escape_string($db, $_POST['reason']);

    $insert_sql = "INSERT INTO reservations (student_id, room_id, reason, status) VALUES ('$idNumber', '$room_id', '$reason', 'Pending')";
    mysqli_query($db, $insert_sql);

    header('Location: reservation_status.php');
    exit();
}

// ajax update 
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['roomId']) && isset($_POST['newValue'])) {
  $roomId = $_POST['roomId'];
  $newValue = $_POST['newValue'];

  // update computer for rooms
  $update_sql = "UPDATE available_rooms SET computers_available = '$newValue' WHERE id = '$roomId'";
  if (mysqli_query($db, $update_sql)) {
      echo 'success';
  } else {
      echo 'error';
  }
  exit(); 
}

// approve button
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['approve_request'])) {
  $reservation_id = $_POST['reservation_id'];
  $update_sql = "UPDATE reservations SET status = 'Approved', updated_at = NOW() WHERE id = '$reservation_id'";
  mysqli_query($db, $update_sql);
  header('Location: reserveadmin.php');
  exit();
}

// deny button
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['deny_request'])) {
  $reservation_id = $_POST['reservation_id'];
  $update_sql = "UPDATE reservations SET status = 'Denied', updated_at = NOW() WHERE id = '$reservation_id'";
  mysqli_query($db, $update_sql);
  header('Location: reserveadmin.php');
  exit();
}


$reservation_query = "SELECT reservations.id, account.firstname, account.lastname, account.idnumber, account.yearlevel, available_rooms.room_name, reservations.status FROM reservations INNER JOIN account ON reservations.firstname = account.firstname AND reservations.lastname = account.lastname INNER JOIN available_rooms ON reservations.room_id = available_rooms.id WHERE account.idnumber = '$idNumber'";
$reservation_result = mysqli_query($db, $reservation_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Dashboard - Search Student</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
<header id="header" class="header fixed-top d-flex align-items-center">

  <div class="d-flex align-items-center justify-content-between">
    <a href="adminsearch.php" class="logo d-flex align-items-center">
      <img src="assets/img/logo.png" alt="">
      <span class="d-none d-lg-block">UC Sit-in System</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div>

  <div class="btn-group" style="left: 76%;">
      <nav class="header-nav ms-auto">
          <ul class="d-flex align-items-center">

              <li class="nav-item dropdown pe-3">
                  <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                      <img src="assets/img/adminlogo.png" alt="Profile" class="rounded-circle">
                      <span class="d-none d-md-block dropdown-toggle ps-2">Admin</span>
                  </a>

              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                  <li class="dropdown-header">
                  <h6>Admin</h6>
                  <span>UC Lab Room Administrator</span>
                  </li>

                  <li>
                  <a class="dropdown-item d-flex align-items-center" href="index.php">
                      <i class="bi bi-box-arrow-right"></i>
                      <span>Sign Out</span>
                  </a>
                  </li>
              </ul>
              </li>
          </ul>
      </nav>
  </div> 
</header>

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link " href="dashboard.php">
          <i class="bi bi-trello"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-heading">Other</li>
      
      <li class="nav-item">
        <a class="nav-link " href="adminsearch.php">
          <i class="bi bi-search"></i>
          <span>Search</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="admindelete.php">
          <i class="bi bi-x-square"></i>
          <span>Delete</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="resetsession.php">
          <i class="bi bi-arrow-repeat"></i>
          <span>Reset Session</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="resetpass.php">
          <i class="bi bi-asterisk"></i>
          <span>Security</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="adminsession.php">
          <i class="bi bi-question-circle"></i>
          <span>View Sit-in Session</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="adminsitin.php">
          <i class="bi bi-envelope"></i>
          <span>View Sit-in Records</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="adminreport.php">
          <i class="bi bi-archive"></i>
          <span>Generate Report</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="postannounce.php">
          <i class="bi bi-blockquote-right"></i>
          <span>Post Announcement</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="adminfeedback.php">
          <i class="bi bi-calendar2"></i>
          <span>View Feedbacks and Reports</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="analytics.php">
          <i class="bi bi-pie-chart"></i>
          <span>Daily Analytics and Reports</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="reserveadmin.php">
          <i class="bi bi-terminal-split"></i>
          <span>Reservation Approval</span>
        </a>
      </li>
    </ul>
  </aside>

  <main id="main" class="main">
    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div>
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title">Add Room</h5>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class= "form-group">
                    <label for="room_name">Room Name:</label>
                    <input type="text" class="form-control" id="room_name" name="room_name" required>
                </div>
                <div class="form-group">
                    <label for="capacity">Capacity:</label>
                    <input type="number" class="form-control" id="capacity" name="capacity" required>
                </div>
                <div class="form-group">
                    <label for="computers_available">Number of Computers Available:</label>
                    <input type="number" class="form-control" id="computers_available" name="computers_available" required>
                </div>
                <br>
                <button type="submit" class="btn btn-primary" name="add_room">Add Room</button>
            </form>
        </div>
    </div>
    <div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title">All Rooms</h5>
    </div>
    <div class="card-body">
    <div class="table-responsive">
        <table class="table table-striped" id="roomsTable">
            <thead>
                <tr>
                    <th>Room Name</th>
                    <th>Capacity</th>
                    <th>Computers Available</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetch all rooms from the database
                $query = "SELECT * FROM available_rooms";
                $result = mysqli_query($db, $query);

                // Display each room in a table row
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$row['room_name']}</td>";
                    echo "<td>{$row['capacity']}</td>";
                    echo "<td><span class='editable' data-id='{$row['id']}' contenteditable>{$row['computers_available']}</span></td>";
                    echo "<td>";
                    echo "<td><button class='btn btn-primary btn-sm edit-btn' data-room-id='{$row['id']}'>Update</button></td>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</div>

    <!-- Card body for displaying user approval requests -->
    <div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title">Student Approval Request</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped" id="roomsTable">
                <thead>
                    <tr>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>ID Number</th>
                        <th>Year</th>
                        <th>Room</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_assoc($reservation_result)) {
                        echo "<tr>";
                        echo "<td>{$row['firstname']}</td>";
                        echo "<td>{$row['lastname']}</td>";
                        echo "<td>{$row['idnumber']}</td>";
                        echo "<td>{$row['yearlevel']}</td>";
                        echo "<td>{$row['room_name']}</td>";
                        echo "<td>";

                        // Check if the status is 'Pending'
                        if ($row['status'] == 'Pending') {
                            echo "<form method='POST' action=''>";
                            // Include the reservation ID as a hidden input field
                            echo "<input type='hidden' name='reservation_id' value='{$row['id']}'>";
                            // Use the correct key name for the request ID
                            echo "<button type='submit' name='approve_request' class='btn btn-success btn-sm me-2'><i class='bi bi-check'></i> Approve</button>";
                            echo "<button type='submit' name='deny_request' class='btn btn-danger btn-sm'><i class='bi bi-x'></i> Deny</button>";                            
                            echo "</form>";
                        } else {
                            // If the status is not 'Pending', do not display the buttons
                            echo "Processed";
                        }

                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</main>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    


    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
    <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chart.js/chart.umd.js"></script>
    <script src="assets/vendor/echarts/echarts.min.js"></script>
    <script src="assets/vendor/quill/quill.js"></script>
    <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>


    <script>
$(document).ready(function() {
    $('.edit-btn').click(function() {
        var roomId = $(this).closest('tr').find('.editable').data('id');
        var newValue = $(this).closest('tr').find('.editable').text().trim(); // Trim whitespace

        // Check if newValue is not empty before sending the AJAX request
        if(newValue !== '') {
            $.ajax({
                url: 'reserveadmin.php',
                method: 'POST',
                data: { roomId: roomId, newValue: newValue },
                success: function(response) {
                    if (response === 'success') {
                        alert('Computers available updated successfully.');
                    } else {
                        alert('Error occurred while updating computers available.');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert('An error occurred while updating computers available.');
                }
            });
        } else {
            alert('New value cannot be empty.');
        }
    });
});


</script>
    </body>

    </html>