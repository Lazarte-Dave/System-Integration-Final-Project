-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2024 at 07:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `davedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middle` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `age` int(200) NOT NULL,
  `idnumber` int(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `yearlevel` int(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL DEFAULT 'student',
  `course` varchar(200) NOT NULL,
  `remaining` int(30) NOT NULL DEFAULT 30
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`user_id`, `firstname`, `middle`, `lastname`, `age`, `idnumber`, `password`, `gender`, `yearlevel`, `contact`, `email`, `address`, `role`, `course`, `remaining`) VALUES
(1, 'Ronald', 'Dave', 'Lazaret', 21, 21540940, 'user', 'Male', 4, '0969521412', 'lazarte@gmail.com', 'Test 1 Street', 'student', 'BSIT', 26),
(2, 'Rey', 'Aaron', 'Crocs', 21, 21540941, 'user', 'Male', 4, '091598213213', 'crocs@gmail.com', 'Test 2 Street', 'student', 'BSIT', 28),
(3, 'Kharl', 'Daggi', 'Daguman', 21, 21540942, 'user', 'Male', 4, '09165445132', 'daguman@gmail.com', 'Test 3 Street', 'student', 'BSIT', 28),
(4, 'Lemarc', 'Carsido', 'Eyac', 21, 21540943, 'user', 'Male', 4, '0914653219', 'eyac@gmail.com', 'Test 4 Street', 'student', 'BSIT', 24),
(5, 'Benedeck', 'Says', 'Cinco', 21, 21540944, 'user', 'Male', 4, '0912123245', 'cinco@gmail.com', 'Test 5 Street', 'student', 'BSIT', 30),
(6, 'Kyle', 'Lem', 'Lim', 21, 21540945, 'user', 'Male', 4, '0966456213', 'lim@gmail.com', 'Test 6 Street', 'student', 'BSIT', 30),
(7, 'Brandon', 'Lee', 'Alcarmen', 21, 21540946, 'user', 'Male', 4, '0945223154', 'alcarmen@gmail.com', 'Test 7 Street', 'student', 'BSIT', 30),
(8, 'Anjie', 'Buaya', 'Alba', 21, 21540947, 'user', 'Female', 4, '0969321454', 'alba@gmail.com', 'Test 8 Street', 'student', 'BSIT', 30);

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `announcement_id` int(11) NOT NULL,
  `ann_notes` text DEFAULT NULL,
  `ann_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`announcement_id`, `ann_notes`, `ann_date`) VALUES
(1, 'TO DAY IS ANOTHER DAY', '2024-05-11 14:19:52'),
(2, 'PANOD NAMO SA SCHOOL STUDENTS', '2024-05-11 14:23:20'),
(3, 'JHOMAR CANUMAY DEAN LIST Month of May', '2024-05-12 01:17:20'),
(4, 'AYO NA ANG AIRCON SA ROOM 432', '2024-05-12 17:42:03');

-- --------------------------------------------------------

--
-- Table structure for table `available_rooms`
--

CREATE TABLE `available_rooms` (
  `id` int(11) NOT NULL,
  `room_name` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL,
  `computers_available` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `available_rooms`
--

INSERT INTO `available_rooms` (`id`, `room_name`, `capacity`, `computers_available`, `created_at`) VALUES
(1, 'Room 524', 50, 22, '2024-05-25 14:19:13'),
(2, 'Room 525', 50, 13, '2024-05-25 14:19:39'),
(3, 'Room 526', 50, 14, '2024-05-25 14:20:16'),
(4, 'Mac Laboratory', 50, 20, '2024-05-25 15:03:16');

-- --------------------------------------------------------

--
-- Table structure for table `deletedstudents`
--

CREATE TABLE `deletedstudents` (
  `deleted_id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middle` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `idnumber` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `yearlevel` int(11) NOT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `role` enum('Student','Admin') NOT NULL DEFAULT 'Student',
  `course` varchar(255) DEFAULT NULL,
  `remaining` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `endedsessions`
--

CREATE TABLE `endedsessions` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `course` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `lab_room` varchar(50) NOT NULL,
  `purpose` varchar(200) NOT NULL,
  `sit_in_time` datetime NOT NULL,
  `sit_out_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `endedsessions`
--

INSERT INTO `endedsessions` (`id`, `firstname`, `lastname`, `id_number`, `course`, `year`, `lab_room`, `purpose`, `sit_in_time`, `sit_out_time`) VALUES
(39, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '524', 'C#', '2024-04-21 11:52:16', '2024-04-21 12:14:12'),
(40, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '525', 'C#', '2024-04-21 11:52:53', '2024-04-21 12:15:51'),
(41, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '525', 'C#', '2024-04-21 11:58:15', '2024-04-21 12:15:54'),
(42, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '525', 'C#', '2024-04-21 11:58:50', '2024-04-21 12:22:07'),
(43, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'Python', '2024-04-21 12:47:31', '2024-04-21 12:47:37'),
(44, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '524', 'C#', '2024-04-21 12:48:05', '2024-04-21 12:48:13'),
(45, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'C#', '2024-04-21 12:50:14', '2024-04-21 12:50:18'),
(46, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'Python', '2024-04-21 12:50:28', '2024-04-21 12:51:58'),
(47, 'ANGELA', 'ALBA', '21457033', 'BSCS', '3', '525', 'Java', '2024-04-21 12:51:31', '2024-04-21 12:51:59'),
(48, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'C#', '2024-04-21 12:51:38', '2024-04-21 12:51:59'),
(49, 'ANGELA', 'ALBA', '21457033', 'BSCS', '3', '525', 'C#', '2024-04-21 12:51:47', '2024-04-21 12:52:00'),
(50, 'DAVE', 'LAZARTE', '21457032', 'BSCS', '3', '526', 'Java', '2024-04-21 12:51:53', '2024-04-21 12:52:01'),
(51, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '525', 'Java', '2024-04-21 14:01:19', '2024-04-21 14:01:23'),
(52, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '524', 'Java', '2024-04-21 14:27:18', '2024-04-21 14:27:28'),
(53, 'BRANDON', 'ALCARMEN', '21457035', 'BSCS', '3', '525', 'Java', '2024-04-21 15:55:44', '2024-04-21 15:56:01'),
(54, 'KYLE', 'LIM', '21457031', 'BSIT', '3', '524', 'Java', '2024-05-11 13:15:22', '2024-05-11 13:15:31'),
(55, 'ALBA', 'ANGELA', '21457033', 'BSCS', '3', '', '', '2024-05-11 13:12:41', '2024-05-11 13:15:47'),
(57, 'IVAN', 'BOOC', '21540944', 'BSIT', '3', '525', 'Java', '2024-05-12 01:19:46', '2024-05-12 01:19:52'),
(58, 'IVAN', 'BOOC', '21540944', 'BSIT', '3', '524', 'Java', '2024-05-12 01:24:13', '2024-05-12 01:24:40'),
(60, 'ALBA', 'ANGELA', '21457033', 'BSCS', '3', '', '', '2024-05-11 13:13:49', '2024-05-12 19:26:48'),
(61, 'ALBA', 'ANGELA', '21457033', 'BSCS', '3', '', '', '2024-05-11 13:13:54', '2024-05-12 19:26:51'),
(62, 'ALBA', 'ANGELA', '21457033', 'BSCS', '3', '', '', '2024-05-11 13:14:28', '2024-05-12 19:26:53'),
(64, 'REY', 'CROCS', '21540941', 'BSIT', '4', '524', 'C#', '2024-05-12 19:28:38', '2024-05-24 03:13:48'),
(65, 'KHARL', 'DAGUMAN', '21540942', 'BSIT', '4', '524', 'C#', '2024-05-12 19:29:17', '2024-05-24 03:13:51'),
(66, 'RONALD', 'LAZARET', '21540940', 'BSIT', '4', '526', 'C#', '2024-05-24 03:22:35', '2024-05-24 03:23:20'),
(67, 'REY', 'CROCS', '21540941', 'BSIT', '4', '526', 'C#', '2024-05-24 03:22:46', '2024-05-24 03:23:22'),
(68, 'KHARL', 'DAGUMAN', '21540942', 'BSIT', '4', '525', 'Java', '2024-05-24 03:22:56', '2024-05-24 03:23:25'),
(69, 'LEMARC', 'EYAC', '21540943', 'BSIT', '4', '525', 'C#', '2024-05-24 03:23:08', '2024-05-24 03:23:28'),
(70, 'RONALD', 'LAZARET', '21540940', 'BSIT', '4', '525', 'C#', '2024-05-24 03:54:59', '2024-05-24 03:55:13'),
(71, 'LEMARC', 'EYAC', '21540943', 'BSIT', '4', '524', 'C#', '2024-05-24 04:04:13', '2024-05-24 04:04:34'),
(72, 'LEMARC', 'EYAC', '21540943', 'BSIT', '4', '525', 'Java', '2024-05-24 04:05:16', '2024-05-24 04:05:19'),
(73, 'LEMARC', 'EYAC', '21540943', 'BSIT', '4', '525', 'Java', '2024-05-24 04:08:36', '2024-05-24 04:10:46'),
(74, 'LEMARC', 'EYAC', '21540943', 'BSIT', '4', '525', 'C#', '2024-05-24 04:12:56', '2024-05-24 04:13:00'),
(75, 'LEMARC', 'EYAC', '21540943', 'BSIT', '4', '525', 'Java', '2024-05-24 04:14:12', '2024-05-24 04:36:40'),
(76, 'RONALD', 'LAZARET', '21540940', 'BSIT', '4', '525', 'Python', '2024-05-24 04:41:49', '2024-05-24 04:42:00');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `feedback_notes` text DEFAULT NULL,
  `feedback_date` datetime DEFAULT NULL,
  `feedback_room` varchar(255) DEFAULT NULL,
  `feedback_purpose` varchar(255) DEFAULT NULL,
  `id_number` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `feedback_notes`, `feedback_date`, `feedback_room`, `feedback_purpose`, `id_number`, `user_id`) VALUES
(1, 'Hola kumusta konichiwa', '2024-05-21 22:34:44', NULL, NULL, NULL, 4),
(2, 'ds', '2024-05-21 22:41:59', NULL, NULL, NULL, 4),
(3, 'Room 524 is good', '2024-05-21 22:43:11', NULL, NULL, NULL, 4),
(4, 'ALL GOOD', '2024-05-24 04:30:03', NULL, NULL, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `room_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sitinsession`
--

CREATE TABLE `sitinsession` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `course` varchar(255) DEFAULT NULL,
  `id_number` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `lab_room` varchar(255) DEFAULT NULL,
  `sit_in_time` datetime DEFAULT NULL,
  `sit_out_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`user_id`) USING BTREE,
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`announcement_id`);

--
-- Indexes for table `available_rooms`
--
ALTER TABLE `available_rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deletedstudents`
--
ALTER TABLE `deletedstudents`
  ADD PRIMARY KEY (`deleted_id`),
  ADD UNIQUE KEY `idnumber` (`idnumber`);

--
-- Indexes for table `endedsessions`
--
ALTER TABLE `endedsessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `fk_feedback_user_id` (`user_id`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `sitinsession`
--
ALTER TABLE `sitinsession`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `available_rooms`
--
ALTER TABLE `available_rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `deletedstudents`
--
ALTER TABLE `deletedstudents`
  MODIFY `deleted_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `endedsessions`
--
ALTER TABLE `endedsessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sitinsession`
--
ALTER TABLE `sitinsession`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `available_rooms` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
